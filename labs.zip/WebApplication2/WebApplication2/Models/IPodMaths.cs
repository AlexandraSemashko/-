﻿namespace WebApplication2.Models
{
    public interface IPodMaths
    {
        InterfaceM tec { get; set; }
        InterfaceM Nov();
    }
}
