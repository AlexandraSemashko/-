﻿namespace WebApplication2.Models
{
    public interface InterfaceM
    {
        int x { get; set; }
        int y { get; set; }

        int Add();
        int Sub();
        int Mult();
        int Div();
    }
}
